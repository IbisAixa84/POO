package com.company;

public class Duenio {

    private String nombre;
    private String apellido;
    private String legajo;

    public Duenio(String nombre, String apellido, String legajo) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.legajo = legajo;
    }


}
