public interface ImpuestoGravable
{
    public double gravar(double porcentaje);
    public double gravar();
}
