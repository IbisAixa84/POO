package animales;

public interface Felino {
    public void treparArbol();
}
