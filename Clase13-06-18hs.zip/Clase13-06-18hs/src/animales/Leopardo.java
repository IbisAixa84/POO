package animales;

public class Leopardo extends Animal implements Felino {
    public Leopardo(String nombre, int edad) {
        super(nombre, edad);
    }

    @Override
    public void hacerRuido() {

    }

    @Override
    public void treparArbol() {

    }
}
