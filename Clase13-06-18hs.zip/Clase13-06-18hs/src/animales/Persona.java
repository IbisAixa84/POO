package animales;

public class Persona {

    Perro miPerro;
}
