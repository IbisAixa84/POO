package personas;

public interface JugadorArgentino {
    public String getProvincia();
}
