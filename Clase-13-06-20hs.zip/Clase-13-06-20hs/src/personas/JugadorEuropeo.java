package personas;

public interface JugadorEuropeo {

    int calcularSalarioEuros(int pesos);
}
