package personas;

public interface Retirado {

    public int aniosRetirados(int anios);
}
